import { GoogleGenAI, Chat, Modality } from "@google/genai";
import { Message, Language } from '../types';

let chat: Chat | null = null;
let currentSystemInstruction: string | null = null;
let ai: GoogleGenAI | null = null;

const getAi = () => {
  if (!ai) {
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }
  return ai;
}

export const getBotResponse = async (
  history: Message[],
  language: Language,
  systemInstruction: string
): Promise<string> => {

  const genAI = getAi();

  // If system instruction changes, create a new chat session
  if (!chat || systemInstruction !== currentSystemInstruction) {
    chat = genAI.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction,
      },
      history: history.slice(0, -1).map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }]
      }))
    });
    currentSystemInstruction = systemInstruction;
  }
  
  const lastMessage = history[history.length - 1];
  if (!lastMessage || lastMessage.sender !== 'user') {
    return "Something went wrong, no user message found.";
  }

  try {
    const response = await chat.sendMessage({ message: lastMessage.text });
    return response.text;
  } catch (error) {
    console.error('Gemini API error:', error);
    // In case of error, reset chat session on next call
    chat = null; 
    currentSystemInstruction = null;
    throw new Error('Failed to get response from Gemini API.');
  }
};

export const getTextToSpeech = async (text: string): Promise<string | null> => {
  const genAI = getAi();
  try {
    const response = await genAI.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' }, // A suitable voice
          },
        },
      },
    });
    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch(error) {
    console.error("Gemini TTS error:", error);
    return null;
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
    const genAI = getAi();
    try {
        const response = await genAI.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
              numberOfImages: 1,
              outputMimeType: 'image/png',
              aspectRatio: '1:1',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/png;base64,${base64ImageBytes}`;
        }
        return null;
    } catch (error) {
        console.error("Imagen API error:", error);
        throw new Error('Failed to generate image from Imagen API.');
    }
};

export const translateText = async (text: string, targetLanguage: 'Kannada' | 'English'): Promise<string> => {
  const genAI = getAi();
  try {
    const response = await genAI.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Translate the following text to ${targetLanguage}. Provide only the raw translated text, without any additional formatting or explanations: "${text}"`,
    });
    return response.text;
  } catch (error) {
    console.error('Gemini translation error:', error);
    throw new Error('Failed to translate text.');
  }
};