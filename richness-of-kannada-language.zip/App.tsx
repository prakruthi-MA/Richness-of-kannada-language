import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Language, Message } from './types';
import { WELCOME_MESSAGES, SYSTEM_INSTRUCTIONS, EXAMPLE_PROMPTS } from './constants';
import { getBotResponse, getTextToSpeech, generateImage, translateText } from './services/geminiService';
import LanguageSelector from './components/LanguageSelector';
import ChatMessage from './components/ChatMessage';
import { SendIcon, BotIcon, SearchIcon, CloseIcon } from './components/Icons';
import TypingIndicator from './components/TypingIndicator';
import ExamplePrompts from './components/ExamplePrompts';
import { decode, decodeAudioData } from './utils/audio';
import WelcomeScreen from './components/WelcomeScreen';


const App: React.FC = () => {
  const [isChatVisible, setIsChatVisible] = useState<boolean>(false);
  const [language, setLanguage] = useState<Language>(Language.ENGLISH);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: Date.now().toString(),
      text: WELCOME_MESSAGES[Language.ENGLISH],
      sender: 'bot',
    },
  ]);
  const [userInput, setUserInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translatingMessageId, setTranslatingMessageId] = useState<string | null>(null);
  const [nowPlaying, setNowPlaying] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const chatEndRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  useEffect(() => {
    const initAudioContext = () => {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      document.removeEventListener('click', initAudioContext, true);
    };
    document.addEventListener('click', initAudioContext, true);
    return () => {
      document.removeEventListener('click', initAudioContext, true);
    };
  }, []);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (searchQuery.trim() === '') {
      scrollToBottom();
    }
  }, [messages, isLoading, searchQuery]);

  const handleLanguageChange = async (newLanguage: Language) => {
    const currentLanguage = language;
    setLanguage(newLanguage);

    if (newLanguage !== currentLanguage && userInput.trim() !== '') {
      const targetLanguage = newLanguage === Language.KANNADA ? 'Kannada' : 'English';
      
      setIsTranslating(true);
      try {
        const translatedText = await translateText(userInput, targetLanguage);
        setUserInput(translatedText);
      } catch (error) {
        console.error("Translation error:", error);
        alert("Sorry, I couldn't translate the text right now.");
      } finally {
        setIsTranslating(false);
      }
    }
  };
  
  const submitAndGetResponse = useCallback(async (history: Message[]) => {
    setIsLoading(true);
    let botResponseText = '';
    try {
        botResponseText = await getBotResponse(history, language, SYSTEM_INSTRUCTIONS[language]);

        if (botResponseText.startsWith('[GENERATE_IMAGE:')) {
            const prompt = botResponseText.substring(botResponseText.indexOf(':') + 1, botResponseText.length - 1).trim();
            const imageMsgId = (Date.now() + 1).toString();

            const placeholderMessage: Message = {
                id: imageMsgId,
                sender: 'bot',
                text: `Generating an image of "${prompt}"...`,
                isLoadingImage: true,
            };
            setMessages((prev) => [...prev, placeholderMessage]);
            setIsLoading(false); // Stop main loading indicator

            try {
                const imageUrl = await generateImage(prompt);
                if (imageUrl) {
                    const finalMessage: Message = {
                        id: imageMsgId,
                        sender: 'bot',
                        text: `Here is an image of "${prompt}"`,
                        isLoadingImage: false,
                        imageUrl: imageUrl,
                    };
                    setMessages((prev) => prev.map(m => m.id === imageMsgId ? finalMessage : m));
                } else {
                    throw new Error("Received no image data.");
                }
            } catch (imageError) {
                console.error("Error generating image:", imageError);
                const errorMessage: Message = {
                    id: imageMsgId,
                    sender: 'bot',
                    text: `Sorry, I couldn't create the image. Please try a different description.`,
                    isError: true,
                    isLoadingImage: false,
                };
                setMessages((prev) => prev.map(m => m.id === imageMsgId ? errorMessage : m));
            }
        } else {
            const botMessage: Message = {
                id: (Date.now() + 1).toString(),
                text: botResponseText,
                sender: 'bot',
            };
            setMessages((prev) => [...prev, botMessage]);
        }
    } catch (error) {
        console.error("Error getting bot response:", error);
        const errorMessage: Message = {
            id: (Date.now() + 1).toString(),
            text: "Sorry, I couldn't get a response. Please check your connection and try again.",
            sender: 'bot',
            isError: true,
        };
        setMessages((prev) => [...prev, errorMessage]);
    } finally {
        if (!botResponseText.startsWith('[GENERATE_IMAGE:')) {
          setIsLoading(false);
        }
    }
  }, [language]);

  const sendMessage = useCallback(async (text: string) => {
    if (text.trim() === '' || isLoading) return;
    setSearchQuery(''); 

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text,
      sender: 'user',
    };
    
    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setUserInput('');
    
    await submitAndGetResponse(newHistory);
  }, [isLoading, messages, submitAndGetResponse]);

  const handleSendMessage = useCallback(async () => {
    sendMessage(userInput);
  }, [userInput, sendMessage]);
  
  const handleRetry = useCallback(async (failedMessageId: string) => {
    const errorIndex = messages.findIndex(m => m.id === failedMessageId);
    if (errorIndex === -1) return;

    const historyForRetry = messages.slice(0, errorIndex);
    
    setMessages(historyForRetry);

    await submitAndGetResponse(historyForRetry);
  }, [messages, submitAndGetResponse]);


  const handlePlayAudio = useCallback(async (textToSpeak: string) => {
    if (nowPlaying || !audioContextRef.current) return;
    
    const ctx = audioContextRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    setNowPlaying(textToSpeak);
    try {
      const base64Audio = await getTextToSpeech(textToSpeak);
      if (base64Audio) {
        const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.start();
        source.onended = () => {
          setNowPlaying(null);
        };
      } else {
        throw new Error("Received empty audio data.");
      }
    } catch (error) {
      console.error("Error playing audio:", error);
      alert("Sorry, the audio couldn't be played at this moment. Please try again later.");
      setNowPlaying(null);
    }
  }, [nowPlaying]);

  const handleTranslate = useCallback(async (messageId: string) => {
    const messageToTranslate = messages.find(m => m.id === messageId);
    if (!messageToTranslate || messageToTranslate.translatedText) return;

    setTranslatingMessageId(messageId);
    try {
        const targetLanguage = language === Language.ENGLISH ? 'Kannada' : 'English';
        const translated = await translateText(messageToTranslate.text, targetLanguage);
        setMessages(prev => prev.map(m =>
            m.id === messageId ? { ...m, translatedText: translated } : m
        ));
    } catch (error) {
        console.error("Translation error on bot message:", error);
        alert("Sorry, the message could not be translated.");
    } finally {
        setTranslatingMessageId(null);
    }
  }, [messages, language]);

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const handleFeedback = (messageId: string, rating: 'good' | 'bad') => {
    setMessages(prevMessages =>
      prevMessages.map(msg => {
        if (msg.id === messageId) {
          return { ...msg, feedback: msg.feedback === rating ? undefined : rating };
        }
        return msg;
      })
    );
    console.log(`Feedback for message ${messageId}: ${rating}`);
  };

  const filteredMessages = searchQuery.trim() === ''
    ? messages
    : messages.filter(msg =>
        msg.text.toLowerCase().includes(searchQuery.trim().toLowerCase())
      );

  if (!isChatVisible) {
    return <WelcomeScreen onEnter={() => setIsChatVisible(true)} />;
  }
  
  const getPlaceholderText = () => {
    if (isTranslating) return 'Translating...';
    return language === Language.ENGLISH ? 'Ask or request an image...' : 'ಕೇಳಿ ಅಥವಾ ಚಿತ್ರವನ್ನು ರಚಿಸಲು ವಿನಂತಿಸಿ...';
  };
  
  return (
    <div className="bg-gradient-to-b from-yellow-400 to-red-500 text-gray-900 flex flex-col h-screen font-sans">
      <header className="bg-white/30 backdrop-blur-md shadow-lg p-4 flex justify-between items-center border-b border-red-500/20">
        <div className="flex items-center space-x-3">
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-white shadow-sm flex items-center justify-center">
            <BotIcon className="h-6 w-6 rounded-sm" />
          </div>
          <h1 className="text-xl font-bold tracking-wider text-red-800 hidden sm:block">ಕನ್ನಡ ಭಾಷೆಯ ಶ್ರೀಮಂತಿಕೆ</h1>
        </div>
        <div className="flex items-center space-x-2">
            <div className="relative">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-red-800/60" aria-hidden="true"/>
                <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search history..."
                    className="w-36 sm:w-48 bg-white/40 border border-red-300/30 rounded-full py-2 pl-10 pr-8 focus:outline-none focus:ring-2 focus:ring-red-500 text-red-900 placeholder-red-800/60 transition-all duration-300"
                />
                {searchQuery && (
                    <button 
                        onClick={() => setSearchQuery('')} 
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-red-200/50"
                        aria-label="Clear search"
                    >
                        <CloseIcon className="h-4 w-4 text-red-800/80" />
                    </button>
                )}
            </div>
            <LanguageSelector
                selectedLanguage={language}
                onSelectLanguage={handleLanguageChange}
            />
        </div>
      </header>
      
      <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {filteredMessages.map((msg) => (
          <ChatMessage 
            key={msg.id} 
            message={msg}
            searchQuery={searchQuery.trim()}
            onPlayAudio={handlePlayAudio}
            nowPlaying={nowPlaying}
            onRetry={handleRetry}
            onFeedback={handleFeedback}
            onTranslate={handleTranslate}
            translatingMessageId={translatingMessageId}
          />
        ))}
        
        {messages.length <= 1 && !isLoading && (
            <ExamplePrompts 
                prompts={EXAMPLE_PROMPTS[language]}
                onPromptClick={sendMessage}
                language={language}
            />
        )}

        {isLoading && <TypingIndicator />}
        <div ref={chatEndRef} />
      </main>

      <footer className="bg-white/30 backdrop-blur-md p-4 border-t border-red-500/20">
        <div className="max-w-3xl mx-auto flex items-center space-x-4">
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={getPlaceholderText()}
            className="flex-1 bg-white/50 border border-red-300/50 rounded-full py-3 px-6 focus:outline-none focus:ring-2 focus:ring-red-500 text-gray-900 placeholder-red-900/60 transition-all duration-300"
            disabled={isLoading || isTranslating}
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || userInput.trim() === ''}
            className="bg-red-600 hover:bg-red-700 disabled:bg-red-400/50 disabled:cursor-not-allowed text-white font-bold rounded-full p-3 transition-colors duration-200 flex items-center justify-center"
            aria-label="Send message"
          >
            <SendIcon className="h-6 w-6" />
          </button>
        </div>
      </footer>
    </div>
  );
};

export default App;