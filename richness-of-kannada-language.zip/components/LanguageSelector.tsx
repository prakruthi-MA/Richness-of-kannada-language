import React from 'react';
import { Language } from '../types';

interface LanguageSelectorProps {
  selectedLanguage: Language;
  onSelectLanguage: (language: Language) => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ selectedLanguage, onSelectLanguage }) => {
  const languages = [
    { id: Language.ENGLISH, name: 'English' },
    { id: Language.KANNADA, name: 'ಕನ್ನಡ' },
  ];

  return (
    <div className="flex bg-white/20 rounded-full p-1 border border-red-500/20">
      {languages.map((lang) => (
        <button
          key={lang.id}
          onClick={() => onSelectLanguage(lang.id)}
          className={`px-4 py-1 text-sm font-semibold rounded-full transition-colors duration-300 focus:outline-none ${
            selectedLanguage === lang.id
              ? 'bg-yellow-400 text-red-900 shadow'
              : 'text-red-800 hover:bg-red-100/50'
          }`}
        >
          {lang.name}
        </button>
      ))}
    </div>
  );
};

export default LanguageSelector;