import React from 'react';
import { ArrowRightIcon, BotIcon, KarnatakaMapIcon } from './Icons';

interface WelcomeScreenProps {
  onEnter: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnter }) => {
  return (
    <div className="h-screen font-sans bg-white text-gray-900 flex flex-col relative overflow-hidden">
      
      <div className="absolute top-0 left-0 -translate-x-1/3 -translate-y-1/3 pointer-events-none" aria-hidden="true">
        <KarnatakaMapIcon className="h-[50vh] w-auto opacity-10" />
      </div>

      <div className="absolute bottom-0 right-0 p-4 sm:p-6 z-20">
        <button
          onClick={onEnter}
          className="bg-red-600 text-white font-bold rounded-full py-3 px-4 hover:bg-red-700 transition-all duration-300 shadow-lg flex items-center space-x-3 group"
          aria-label="Enter chatbot"
        >
          <span className="hidden sm:inline text-md font-semibold">Enter Chat</span>
          <ArrowRightIcon className="h-6 w-6 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      <main className="flex-1 flex flex-col items-center justify-center text-center p-4 animate-fade-in relative z-10">
        <div>
          <div className="bg-yellow-100/50 rounded-full p-4 mb-6 inline-block shadow-lg border border-yellow-300/50">
            <BotIcon className="h-20 w-20 rounded-sm" />
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-4 text-red-800 drop-shadow-sm" style={{ fontFamily: "'Noto Sans Kannada', sans-serif" }}>
            ಕನ್ನಡ ಭಾಷೆಯ ಶ್ರೀಮಂತಿಕೆ
          </h1>
          <p className="text-xl md:text-2xl font-semibold text-yellow-600" style={{ fontFamily: "'Noto Sans Kannada', sans-serif" }}>
            ಸಿರಿಗನ್ನಡಂ ಗೆಲ್ಗೆ, ಸಿರಿಗನ್ನಡಂ ಬಾಳ್ಗೆ
          </p>
        </div>
      </main>

      <footer className="p-4 text-center text-gray-500 text-sm relative z-10">
        <p>&copy; {new Date().getFullYear()} ಕನ್ನಡ ಭಾಷೆಯ ಶ್ರೀಮಂತಿಕೆ AI. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default WelcomeScreen;