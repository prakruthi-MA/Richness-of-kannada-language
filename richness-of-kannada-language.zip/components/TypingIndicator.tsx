import React from 'react';
import { BotIcon } from './Icons';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-start gap-3 justify-start">
      <div className="flex-shrink-0 h-8 w-8 rounded-full bg-white shadow-sm flex items-center justify-center mt-1">
        <BotIcon className="h-6 w-6 rounded-sm" />
      </div>
      <div className="max-w-xl px-5 py-3 rounded-2xl rounded-tl-none bg-white flex items-center space-x-1.5 shadow-md">
          <span className="h-2 w-2 bg-red-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
          <span className="h-2 w-2 bg-red-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
          <span className="h-2 w-2 bg-red-500 rounded-full animate-bounce"></span>
      </div>
    </div>
  );
};

export default TypingIndicator;