import React from 'react';
import { Language } from '../types';

interface ExamplePromptsProps {
  prompts: string[];
  onPromptClick: (prompt: string) => void;
  language: Language;
}

const ExamplePrompts: React.FC<ExamplePromptsProps> = ({ prompts, onPromptClick, language }) => {
  return (
    <div className="max-w-xl lg:max-w-2xl mx-auto animate-fade-in">
        <h3 className="text-center text-sm font-semibold text-red-800/80 mb-3">
            {language === Language.ENGLISH ? 'Try asking:' : 'ಇದನ್ನು ಕೇಳಿ ನೋಡಿ:'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {prompts.map((prompt, index) => (
                <button
                    key={index}
                    onClick={() => onPromptClick(prompt)}
                    className="text-left p-3 bg-white/30 backdrop-blur-sm border border-red-300/30 rounded-lg hover:bg-white/50 transition-all duration-200 text-red-900 text-sm"
                >
                    {prompt}
                </button>
            ))}
        </div>
    </div>
  );
};

export default ExamplePrompts;