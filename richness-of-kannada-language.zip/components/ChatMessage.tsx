import React from 'react';
import { Message } from '../types';
import { BotIcon, UserIcon, SpeakerIcon, LoadingIcon, ThumbsUpIcon, ThumbsDownIcon, PhotoIcon, TranslateIcon } from './Icons';

interface ChatMessageProps {
  message: Message;
  onPlayAudio: (text: string) => void;
  nowPlaying: string | null;
  searchQuery?: string;
  onRetry?: (messageId: string) => void;
  onFeedback?: (messageId: string, rating: 'good' | 'bad') => void;
  onTranslate?: (messageId: string) => void;
  translatingMessageId?: string | null;
}

const highlight = (text: string, query: string): React.ReactNode => {
    if (!query) return text;
    const regex = new RegExp(`(${query})`, 'gi');
    return (
        <>
            {text.split(regex).map((part, i) =>
                part.toLowerCase() === query.toLowerCase() ? (
                    <mark key={i} className="bg-yellow-200 text-black rounded px-0.5 py-0">
                        {part}
                    </mark>
                ) : (
                    part
                )
            )}
        </>
    );
};

const ImageLoadingPlaceholder: React.FC = () => (
    <div className="mt-2 aspect-square w-64 bg-gray-200/50 rounded-lg flex flex-col items-center justify-center animate-pulse">
        <PhotoIcon className="h-10 w-10 text-gray-400" />
        <p className="mt-2 text-sm text-gray-500">Creating image...</p>
    </div>
);

const ChatMessage: React.FC<ChatMessageProps> = ({ 
    message, 
    onPlayAudio, 
    nowPlaying, 
    searchQuery = '', 
    onRetry, 
    onFeedback, 
    onTranslate,
    translatingMessageId,
}) => {
  const isBot = message.sender === 'bot';

  const messageClasses = isBot
    ? message.isError ? 'bg-red-100 text-red-800' : 'bg-white text-gray-800'
    : 'bg-yellow-400 text-red-900';
  
  const containerClasses = isBot ? 'justify-start' : 'justify-end';
  
  const renderTextContent = (text: string) => {
    if (!isBot) {
      return <p className="whitespace-pre-wrap">{highlight(text, searchQuery)}</p>;
    }

    const parts = text.split(/(\[\[.*?\]\]\s*\(.*?\))/g);

    return parts.map((part, index) => {
      const match = /\[\[(.*?)\]\]\s*\((.*?)\)/.exec(part);
      if (match) {
        const [, kannadaText, phoneticText] = match;
        const isCurrentlyPlaying = nowPlaying === kannadaText;
        return (
          <span key={index} className="inline-flex items-center gap-1 bg-red-100/50 rounded-md px-1.5 py-0.5">
            <span className="font-bold">{highlight(kannadaText, searchQuery)}</span>
            <span className="text-sm text-red-800/80 italic">({highlight(phoneticText, searchQuery)})</span>
            <button 
              onClick={() => onPlayAudio(kannadaText)} 
              disabled={!!nowPlaying}
              className="disabled:opacity-50 disabled:cursor-wait"
              aria-label={`Play audio for ${kannadaText}`}
            >
              {isCurrentlyPlaying ? <LoadingIcon className="h-4 w-4 text-red-600 animate-spin" /> : <SpeakerIcon className="h-4 w-4 text-red-600" />}
            </button>
          </span>
        );
      }
      return <span key={index}>{highlight(part, searchQuery)}</span>;
    });
  };

  const mainContent = () => {
    if (message.isError && onRetry) {
        return (
            <div className="flex flex-col items-start gap-2">
                <p>{highlight(message.text, searchQuery)}</p>
                <button
                    onClick={() => onRetry(message.id)}
                    className="bg-transparent border border-red-600 text-red-700 hover:bg-red-600 hover:text-white text-sm font-semibold py-1 px-3 rounded-full transition-colors duration-200"
                >
                    Retry
                </button>
            </div>
        );
    }
    return renderTextContent(message.text);
  };


  return (
    <div className={`flex items-start gap-3 ${containerClasses}`}>
      {isBot && <div className="flex-shrink-0 h-8 w-8 rounded-full bg-white shadow-sm flex items-center justify-center mt-1">
        <BotIcon className="h-6 w-6 rounded-sm" />
      </div>}
      <div className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}>
        <div className={`max-w-xl lg:max-w-2xl px-5 py-3 rounded-2xl shadow-md ${messageClasses} ${isBot ? 'rounded-tl-none' : 'rounded-tr-none'}`}>
          <div className="whitespace-pre-wrap leading-relaxed">{mainContent()}</div>
          
          {message.translatedText && (
            <div className="mt-3 pt-3 border-t border-red-200/50">
              <div className="whitespace-pre-wrap leading-relaxed text-gray-700/90">{renderTextContent(message.translatedText)}</div>
            </div>
          )}

          {message.isLoadingImage && <ImageLoadingPlaceholder />}
          {message.imageUrl && (
            <div className="mt-2">
                <img src={message.imageUrl} alt={message.text} className="rounded-lg max-w-xs lg:max-w-sm" />
            </div>
          )}
        </div>
        
        {isBot && !message.isError && !message.isLoadingImage && (onFeedback || onTranslate) && (
          <div className="flex items-center space-x-2 mt-2">
            {onFeedback && (
              <>
                <button 
                  onClick={() => onFeedback(message.id, 'good')} 
                  className="p-1 rounded-full hover:bg-gray-200/50 transition-colors"
                  aria-label="Good response"
                >
                  <ThumbsUpIcon 
                    className={`h-5 w-5 transition-colors ${message.feedback === 'good' ? 'text-green-600' : 'text-gray-500 hover:text-gray-700'}`} 
                    isFilled={message.feedback === 'good'}
                  />
                </button>
                <button 
                  onClick={() => onFeedback(message.id, 'bad')} 
                  className="p-1 rounded-full hover:bg-gray-200/50 transition-colors"
                  aria-label="Bad response"
                >
                  <ThumbsDownIcon 
                    className={`h-5 w-5 transition-colors ${message.feedback === 'bad' ? 'text-red-700' : 'text-gray-500 hover:text-gray-700'}`} 
                    isFilled={message.feedback === 'bad'}
                  />
                </button>
              </>
            )}
            {onTranslate && (
                 <button 
                    onClick={() => onTranslate(message.id)} 
                    className="p-1 rounded-full hover:bg-gray-200/50 transition-colors disabled:cursor-wait"
                    disabled={!!translatingMessageId || !!message.translatedText}
                    aria-label="Translate message"
                >
                    {translatingMessageId === message.id 
                        ? <LoadingIcon className="h-5 w-5 animate-spin text-gray-500"/> 
                        : <TranslateIcon className={`h-5 w-5 ${message.translatedText ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700'}`} />
                    }
                </button>
            )}
          </div>
        )}
      </div>
      {!isBot && <div className="flex-shrink-0 h-8 w-8 rounded-full bg-yellow-500/80 flex items-center justify-center mt-1"><UserIcon className="h-5 w-5 text-red-900" /></div>}
    </div>
  );
};

export default ChatMessage;