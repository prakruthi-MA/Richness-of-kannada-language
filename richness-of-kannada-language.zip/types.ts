export enum Language {
  ENGLISH = 'english',
  KANNADA = 'kannada',
}

export interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  isError?: boolean;
  feedback?: 'good' | 'bad';
  imageUrl?: string;
  isLoadingImage?: boolean;
  translatedText?: string;
}